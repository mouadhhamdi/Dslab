# Week 11: Homework 4

The graded homework is contained in the `Homework4.ipynb` notebook.

As always, fork this repository into your own namespace. The contents of your
forked repo on the due date will graded.

There are three parts which can be done independently.

## Python setup

You can run the notebook in the cluster or on your laptop. In the latter case,
you will probably need to install the following packages:

```bash
pip install pyspark==2.2.1 pykafka pyproj
```
